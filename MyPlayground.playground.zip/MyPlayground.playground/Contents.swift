//: Playground - noun: a place where people can play
    
import UIKit

var greeting = "Hello, playground"
greeting = "Goodbye"

var age = 38;
var population = 8_000_000

var exp = """
    Will this all
    print on one
    line or will
    it print over
    multiple lines?
    """

var exp2 = """
    Will this all \
    print on one \
    line or will \
    it print over \
    multiple lines?
    """

var exp3 = """
    Will this all print on one line or will it print over multiple lines?
    """

var score = 99
var str = "Your score was \(score)"
var results = "The test results are here: \(str)"

let album: String = "Dying Star"
let year: Int = 30
let change: Double = 44.37
let locked: Bool = false
