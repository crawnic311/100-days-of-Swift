//: Playground - noun: a place where people can play
    
import UIKit

var greeting = "Hello, playground"
greeting = "Goodbye"

//variables
var age = 38;
var population = 8_000_000

//multi-line strings
var exp = """
    Will this all
    print on one
    line or will
    it print over
    multiple lines?
    """

var exp2 = """
    Will this all \
    print on one \
    line or will \
    it print over \
    multiple lines?
    """

var exp3 = """
    Will this all print on one line or will it print over multiple lines?
    """

//string interpolations
var score = 99
var str = "Your score was \(score)"
var results = "The test results are here: \(str)"

//constants and type annotations
let album: String = "Dying Star"
let year: Int = 30
let change: Double = 44.37
let locked: Bool = false

//arrays
let singer = "Brandon Boyd"
let guitarist = "Mike Enzinger"
let bassist = "Ben Kenny"
let drummer = "Jose Pasalis"

let incubus: [String] = [singer, guitarist, bassist, drummer]
incubus[1]

//sets
let water = Set(["wet", "useful", "essential", "variable"])
let box = Set([1, 4.3])

//tuples
var tuple = (west: "taylor", "James")
tuple.west
tuple.0
tuple.0 = "candy"
tuple.0
tuple.west

//dictionaries
let recipe = [
    "beefbroth": 1,
    "chickenbroth": 1,
    "cottoncandy": 7
    ]
recipe["beefbroth"]
recipe["cottoncandy"]

//empty dictionaries
var books = [String: String]()
books["LOTR"] = "Best"
books["LOTR"]
books["Dune"] = "Revolutionary"
books["Dune"]

//empty arrays, adding to arrays
var scores = [Int]()
scores = [1]
scores[0]
scores += [2]
scores[0]
scores[1]
scores.append(4)
scores[2]

//empty sets *********************
var keys = Set<String>()
keys = ["house"]





var doubles = Set<Double>()

